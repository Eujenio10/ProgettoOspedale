# GESTIONE OSPEDALE - Distribuzione

## 📋 Istruzioni di Installazione

### 1. Installazione
1. Estrarre tutti i file in una cartella
2. Eseguire `install.bat` come amministratore
3. L'applicazione verrà installata sul desktop

### 2. Prima Esecuzione
1. Fare doppio click su "Gestione Ospedale" sul desktop
2. Inserire l'ID impiegato dal file `impiegati.csv`
3. L'applicazione creerà automaticamente il database

### 3. Aggiornamento Database
Per aggiornare il database con nuovi dati:
1. Sostituisci `impiegati.csv` con la nuova versione
2. Eseguire `update_database.bat`
3. Il database verrà aggiornato automaticamente

## 📁 Struttura File

- `GestioneOspedale.exe` - Applicazione principale
- `ospedale.db` - Database SQLite
- `impiegati.csv` - Lista impiegati
- `install.bat` - Script di installazione
- `update_database.bat` - Script aggiornamento

## 🔧 Configurazione Multi-PC

### Sincronizzazione Database
Per sincronizzare il database tra più PC:

1. **Esporta backup** dall'applicazione:
   - Menu → Backup Database
   - Salva il file .sql

2. **Distribuisci il backup**:
   - Copia il file .sql su tutti i PC
   - Usa "Import Backup" nell'applicazione

3. **Aggiorna impiegati**:
   - Sostituisci `impiegati.csv` su tutti i PC
   - Esegui `update_database.bat`

## 📞 Supporto Tecnico

Per problemi di installazione o aggiornamento:
- Controllare che tutti i file siano presenti
- Verificare i permessi di amministratore
- Controllare che il database non sia bloccato

## 🔒 Sicurezza

- Il database è locale su ogni PC
- I backup contengono tutti i dati
- Gli aggiornamenti non sovrascrivono dati esistenti
- Backup automatico prima di ogni aggiornamento

---
*Sistema di Gestione Ospedaliera v1.0*
